# -*- coding: utf-8 -*-
"""
Created on Mon Dec 20 15:54:06 2021
@author: Laura K. Harris, Ph.D.
"""

import os
import numpy as np
import pandas as pd
import scipy
import gseapy as gp
from gseapy.plot import gseaplot

def zscore(df, datasetnum):
    tempnum = 0
    df2 = pd.DataFrame()
    totalrows = df[df.columns[0]].count()

    while tempnum < (totalrows):
        zscorearray = []
        temparray = df.iloc[tempnum].to_numpy()
        geneID = temparray[0]
        temparray = np.delete(temparray, 0, 0)

        mean = np.mean(temparray)
        std = np.std(temparray)

        for value in temparray:
            tempz = (value - mean) / std
            zscorearray = np.append(zscorearray, tempz)
        tempseries = pd.Series(zscorearray, name = geneID)
        df2 = df2.append(tempseries)
        
        if tempnum % 1000 == 0:
            print('Z-scoring gene #' + str(tempnum))
        tempnum = tempnum + 1
    
    df2copy = df2
    header = list(df.head(0))
    header.pop(0)
    df2.columns = header
    
    filename = 'output\Zscoredata' + str(datasetnum) + '.txt'
    df2.to_csv(filename, sep='\t', index=True) #change file name as needed
    print('Z-score done for dataset #' + str(datasetnum))
    print()
    return df2copy

def Tscore(df, controlcols, experimentalcols, datasetnum):
    dfstat = pd.DataFrame()
    dfpval = pd.DataFrame()
    tempnum = 0
    for r in df.iterrows():
        geneID = r[0]
        row = r[1]
        controlvals = []
        experimentalvals = []
        for iter in controlcols:
            controlvals.append(row[iter])
        for iter in experimentalcols:
            experimentalvals.append(row[iter])
        stat, pval = scipy.stats.ttest_ind(experimentalvals, controlvals, equal_var=False)
        tempstatseries = pd.Series(stat, name = geneID)
        temppvalseries = pd.Series(pval, name = geneID)
        dfstat = dfstat.append(tempstatseries)
        dfpval = dfpval.append(temppvalseries)
        
        if tempnum % 1000 == 0:
            print('T-scoring gene #' + str(tempnum))
        tempnum = tempnum + 1
        
    dfstat.columns = ['Tscore']
    df2 = pd.concat([dfstat, dfpval], axis = 1)
    df2.columns = ['Tscore', 'pval']
    filename = 'output\Tscoredata' + str(datasetnum) + '.txt' #change file name as needed
    df2.to_csv(filename, sep='\t', index=True) 
    dfstat = dfstat.sort_values(by=['Tscore'], ascending=False)
    print('Tscore done for dataset #' + str(datasetnum))
    return dfstat

def querygen(df, querysetsize, datasetnum):
    dfquery = pd.DataFrame()
    dfhighest = df['Tscore'].nlargest(querysetsize)
    dflowest = df['Tscore'].nsmallest(querysetsize)
    highestlist = pd.Index.tolist(dfhighest.index)
    lowestlist = pd.Index.tolist(dflowest.index)
    
    highestlist.insert(0, ('positivetail' + str(datasetnum)))
    highestlist.insert(1, 'spacer')
    lowestlist.insert(0, ('negativetail' + str(datasetnum)))
    lowestlist.insert(1, 'spacer')
    
    highestSeries = pd.Series(highestlist)
    lowestSeries = pd.Series(lowestlist)
    dfquery = pd.concat([highestSeries, lowestSeries], axis = 1)
    dfquery = dfquery.T
    print('Query set generation done!')
    print()
    return dfquery

def prerankGSEA(refsigdf, datasetnum):
    outputdir = 'output\GSEAGeneID' + str(datasetnum)
    preresult = gp.prerank(refsigdf, 'output\Querysetdata.gmt', outdir=outputdir, pheno_pos='Pos', pheno_neg='Neg',
            min_size=15, max_size=500, permutation_num=1000, weighted_score_type=1,
            ascending=False, processes=1, figsize=(6.5,6), format='jpg',
            graph_num=20, no_plot=False, seed=None, verbose=False)
    preresult.run()

    terms = preresult.res2d.index
    i = 0
    for iter in terms:
        gseaplot(rank_metric=preresult.ranking, term=terms[i], **preresult.results[terms[i]])
        i = i + 1


df1 = pd.read_csv('GSE32861data.txt', low_memory=False, delimiter = "\t") #change file name as needed
df2 = pd.read_csv('GSE32866data.txt', low_memory=False, delimiter = "\t") #change file name as needed
cwd = os.getcwd()
path = cwd + "\output"
if not os.path.exists(path):
    os.mkdir(path)

#call function to zscore data    
normalizeddf1 = zscore(df1, 1)
normalizeddf2 = zscore(df2, 2)

controlcols = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32,
               34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62, 64,
               66, 68, 70, 72, 74, 76, 78, 80, 82, 84, 86, 88, 90, 92, 94, 96,
               98, 100, 102, 104, 106, 108, 110, 112, 114, 116] #change column indices as needed for df1
for l in controlcols:
    print(normalizeddf1.columns[l]) #check this output to ensure proper column selection
print()

experimentalcols = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31,
                    33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59, 61,
                    63, 65, 67, 69, 71, 73, 75, 77, 79, 81, 83, 85, 87, 89, 91,
                    93, 95, 97, 99, 101, 103, 105, 107, 109, 111, 113, 115, 117] #change column indices as needed for df1
for l in experimentalcols:
    print(normalizeddf1.columns[l]) #check this output to ensure proper column selection
print()

refsigdf1 = Tscore(normalizeddf1, controlcols, experimentalcols, 1)

controlcols = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18,
               19, 20, 21, 22, 23, 24, 25, 26] #change column indices as needed for df2
for l in controlcols:
    print(normalizeddf2.columns[l]) #check this output to ensure proper column selection
print()
experimentalcols = [27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41,
                    42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54] #change column indices as needed for df2
for l in experimentalcols:
    print(normalizeddf2.columns[l]) #check this output to ensure proper column selection
print()
    
refsigdf2 = Tscore(normalizeddf2, controlcols, experimentalcols, 2)

dfquery1 = querygen(refsigdf1, 500, 1) #change 500 to needed query set size
dfquery2 = querygen(refsigdf2, 500, 2) #change 500 to needed query set size
querydf = pd.concat([dfquery1, dfquery2], axis = 0)
querydf.to_csv('output\Querysetdata.gmt', sep='\t', index=False)

prerankGSEA(refsigdf1, 1)
prerankGSEA(refsigdf2, 2)