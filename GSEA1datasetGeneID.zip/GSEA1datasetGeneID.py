# -*- coding: utf-8 -*-
"""
Created on Mon Dec 20 15:54:06 2021
@author: Laura K. Harris, Ph.D.
"""

import os
import numpy as np
import pandas as pd
import scipy
import gseapy as gp
from gseapy.plot import gseaplot

def zscore(df):
    tempnum = 0
    df2 = pd.DataFrame()
    totalrows = df[df.columns[0]].count()

    while tempnum < (totalrows):
        zscorearray = []
        temparray = df.iloc[tempnum].to_numpy()
        geneID = temparray[0]
        temparray = np.delete(temparray, 0, 0)

        mean = np.mean(temparray)
        std = np.std(temparray)

        for value in temparray:
            tempz = (value - mean) / std
            zscorearray = np.append(zscorearray, tempz)
        tempseries = pd.Series(zscorearray, name = geneID)
        df2 = df2.append(tempseries)
        
        if tempnum % 1000 == 0:
            print('Z-scoring gene #' + str(tempnum))
        tempnum = tempnum + 1
    
    df2copy = df2
    header = list(df.head(0))
    header.pop(0)
    df2.columns = header
    
    filename = 'output\Zscoredata.txt'
    df2.to_csv(filename, sep='\t', index=True) #change file name as needed
    print('Z-score done')
    print()
    return df2copy

def Tscore(df, controlcols, experimentalcols, datasetnum):
    dfstat = pd.DataFrame()
    dfpval = pd.DataFrame()
    tempnum = 0
    for r in df.iterrows():
        geneID = r[0]
        row = r[1]
        controlvals = []
        experimentalvals = []
        for iter in controlcols:
            controlvals.append(row[iter])
        for iter in experimentalcols:
            experimentalvals.append(row[iter])
        stat, pval = scipy.stats.ttest_ind(experimentalvals, controlvals, equal_var=False)
        tempstatseries = pd.Series(stat, name = geneID)
        temppvalseries = pd.Series(pval, name = geneID)
        dfstat = dfstat.append(tempstatseries)
        dfpval = dfpval.append(temppvalseries)
        
        if tempnum % 1000 == 0:
            print('T-scoring gene #' + str(tempnum))
        tempnum = tempnum + 1
        
    dfstat.columns = ['Tscore']
    df2 = pd.concat([dfstat, dfpval], axis = 1)
    df2.columns = ['Tscore', 'pval']
    filename = 'output\Tscoredata' + str(datasetnum) + '.txt'
    df2.to_csv(filename, sep='\t', index=True) #change file name as needed
    dfstat = dfstat.sort_values(by=['Tscore'], ascending=False)
    print('Tscore done for dataset #' + str(datasetnum))
    return dfstat

def querygen(df, querysetsize, datasetnum):
    dfquery = pd.DataFrame()
    dfhighest = df['Tscore'].nlargest(querysetsize)
    dflowest = df['Tscore'].nsmallest(querysetsize)
    highestlist = pd.Index.tolist(dfhighest.index)
    lowestlist = pd.Index.tolist(dflowest.index)
    
    highestlist.insert(0, ('positivetail' + str(datasetnum)))
    highestlist.insert(1, 'spacer')
    lowestlist.insert(0, ('negativetail' + str(datasetnum)))
    lowestlist.insert(1, 'spacer')
    
    highestSeries = pd.Series(highestlist)
    lowestSeries = pd.Series(lowestlist)
    dfquery = pd.concat([highestSeries, lowestSeries], axis = 1)
    dfquery = dfquery.T
    print('Query set generation done!')
    print()
    return dfquery

def prerankGSEA(refsigdf, datasetnum):
    outputdir = 'output\GSEAGeneID' + str(datasetnum)
    preresult = gp.prerank(refsigdf, 'output\Querysetdata.gmt', outdir=outputdir, pheno_pos='Pos', pheno_neg='Neg',
            min_size=15, max_size=500, permutation_num=1000, weighted_score_type=1,
            ascending=False, processes=1, figsize=(6.5,6), format='jpg',
            graph_num=20, no_plot=False, seed=None, verbose=False)
    preresult.run()

    terms = preresult.res2d.index
    i = 0
    for iter in terms:
        gseaplot(rank_metric=preresult.ranking, term=terms[i], **preresult.results[terms[i]])
        i = i + 1


df = pd.read_csv('GSE32861data.txt', low_memory=False, delimiter = "\t") #change file name as needed
cwd = os.getcwd()
path = cwd + "\output"
if not os.path.exists(path):
    os.mkdir(path)

#call function to zscore data    
normalizeddf = zscore(df)

#separate samples into half experimental and controls groups (4 group total)
split = int(((len(normalizeddf.columns))/2))
IDsamples1 = []
IDsamples2 = []
for i in range(split):
    IDsamples1.append(i)
    IDsamples2.append(split+i) 

controlcols1 = []
controlcols2 = []
experimentalcols1 = []
experimentalcols2 = []
if int(len(IDsamples1)) % 2 == 0:
    for i in IDsamples1:
        if IDsamples1[i] % 2 == 0:
            controlcols1.append(IDsamples1[i])
            controlcols2.append(IDsamples2[i])   
        else:
            experimentalcols1.append(IDsamples1[i])
            experimentalcols2.append(IDsamples2[i])
else:
    for i in IDsamples1:
        if IDsamples1[i] % 2 == 0:
            controlcols2.append(IDsamples1[i])
            experimentalcols1.append(IDsamples2[i])
        else:
            experimentalcols2.append(IDsamples1[i])
            controlcols1.append(IDsamples2[i])

for l in controlcols1:
    print(normalizeddf.columns[l]) #check this output to ensure proper column selection
print()
for l in experimentalcols1:
    print(normalizeddf.columns[l]) #check this output to ensure proper column selection
print()
refsigdf1 = Tscore(normalizeddf, controlcols1, experimentalcols1, 1)
print()
for l in controlcols2:
    print(normalizeddf.columns[l]) #check this output to ensure proper column selection
print()
for l in experimentalcols2:
    print(normalizeddf.columns[l]) #check this output to ensure proper column selection
print()
refsigdf2 = Tscore(normalizeddf, controlcols2, experimentalcols2, 2)

dfquery1 = querygen(refsigdf1, 500, 1) #change 500 to needed query set size
dfquery2 = querygen(refsigdf2, 500, 2) #change 500 to needed query set size
querydf = pd.concat([dfquery1, dfquery2], axis = 0)
querydf.to_csv('output\Querysetdata.gmt', sep='\t', index=False)

prerankGSEA(refsigdf1, 1)
prerankGSEA(refsigdf2, 2)