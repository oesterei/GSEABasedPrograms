# -*- coding: utf-8 -*-
"""
Created on Mon Dec 20 15:54:06 2021
@author: Laura K. Harris, Ph.D.
"""

import os
import numpy as np
import pandas as pd
import scipy
import gseapy as gp
from gseapy.plot import gseaplot
import random


def zscore(df):
    tempnum = 0
    df2 = pd.DataFrame()
    totalrows = df[df.columns[0]].count()

    while tempnum < (totalrows):
        zscorearray = []
        temparray = df.iloc[tempnum].to_numpy()
        geneID = temparray[0]
        temparray = np.delete(temparray, 0, 0)

        mean = np.mean(temparray)
        std = np.std(temparray)

        for value in temparray:
            tempz = (value - mean) / std
            zscorearray = np.append(zscorearray, tempz)
        tempseries = pd.Series(zscorearray, name = geneID)
        df2 = df2.append(tempseries)
        
        if tempnum % 1000 == 0:
            print('Z-scoring gene #' + str(tempnum))
        tempnum = tempnum + 1
    filename = 'output\Zscoredata.txt'
    df2.to_csv(filename, sep='\t', index=True) #change file name as needed
    print('Z-score done')
    print()
    return df2

def Tscore(df, controlcols, experimentalcols, datasetnum):
    dfstat = pd.DataFrame()
    dfpval = pd.DataFrame()
    tempnum = 0
    for r in df.iterrows():
        geneID = r[0]
        row = r[1]
        controlvals = []
        experimentalvals = []
        for iter in controlcols:
            controlvals.append(row[iter])
        for iter in experimentalcols:
            experimentalvals.append(row[iter])
        stat, pval = scipy.stats.ttest_ind(experimentalvals, controlvals, equal_var=False)
        tempstatseries = pd.Series(stat, name = geneID)
        temppvalseries = pd.Series(pval, name = geneID)
        dfstat = dfstat.append(tempstatseries)
        dfpval = dfpval.append(temppvalseries)
        
        if tempnum % 1000 == 0:
            print('T-scoring gene #' + str(tempnum))
        tempnum = tempnum + 1
        
    dfstat.columns = ['Tscore']
    dfstat.sort_values(by=['Tscore'], ascending=False, inplace=True)
    df2 = pd.concat([dfstat, dfpval], axis = 1)
    df2.columns = ['Tscore', 'pval']
    filename = 'output\Tscoredata' + str(datasetnum) + '.txt'
    df2.to_csv(filename, sep='\t', index=True) #change file name as needed
    print('Tscore done for dataset #' + str(datasetnum))
    return dfstat

def prerankGSEA(refsigdf, folder, queryset, datasetnum):
    outputdir = 'output' + str(folder) + str(datasetnum)
    preresult = gp.prerank(refsigdf, queryset, outdir=outputdir, pheno_pos='Pos', pheno_neg='Neg',
            min_size=15, max_size=500, permutation_num=1000, weighted_score_type=1,
            ascending=False, processes=1, figsize=(6.5,6), format='jpg',
            graph_num=20, no_plot=False, seed=None, verbose=False)
    preresult.run()

    terms = preresult.res2d.index
    i = 0
    for iter in terms:
        gseaplot(rank_metric=preresult.ranking, term=terms[i], **preresult.results[terms[i]])
        i = i + 1

def shuffle(verifysigdf, querysize):
    df3 = pd.DataFrame()
    listofgenes = verifysigdf.index
    listofgenes = list(verifysigdf.index)
    querysize = int(querysize)
    for i in range(1000):
        random.shuffle(listofgenes)
        temprandomlist = listofgenes[0:querysize]
        temprandomlist.insert(0, ('random' + str(i)))
        temprandomlist.insert(1, 'spacer')
        a_series = pd.Series(temprandomlist)
        df3 = df3.append(a_series, ignore_index=True)
        if i % 100 == 0:
            print('Random list #' + str(i))
    return df3
    

df = pd.read_csv('GSE139032data.txt', low_memory=False, delimiter = "\t") #change file name as needed
cwd = os.getcwd()
path = cwd + "\output"
if not os.path.exists(path):
    os.mkdir(path)

controlcols = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32,
               34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62, 64,
               66, 68, 70, 72, 74, 76, 78, 80, 82, 84, 86, 88, 90, 92, 94, 96,
               98, 100, 102, 104, 106, 108, 110, 112, 114, 116, 118, 120, 122,
               124, 126, 128, 130, 132, 134, 136, 138, 140, 142, 144, 146, 148,
               150, 152] #change as needed
for l in controlcols:
    print(df.columns[l+1]) #check this output to ensure proper column selection
print()
experimentalcols = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31,
                    33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59, 61,
                    63, 65, 67, 69, 71, 73, 75, 77, 79, 81, 83, 85, 87, 89, 91,
                    93, 95, 97, 99, 101, 103, 105, 107, 109, 111, 113, 115, 117,
                    119, 121, 123, 125, 127, 129, 131, 133, 135, 137, 139, 141, 
                    143, 145, 147, 149, 151, 153] #change as needed
for l in experimentalcols:
    print(df.columns[l+1]) #check this output to ensure proper column selection
print()

normalizeddf = zscore(df)   
verifysigdf = Tscore(normalizeddf, controlcols, experimentalcols, 1)
prerankGSEA(verifysigdf, '\GSEAGeneverify', 'paneldata.gmt', 3) #change file name as needed

#Random model
dfpanel = pd.read_csv('paneldata.gmt', low_memory=False, delimiter = "\t", header=None)

tempsum = 0
for row in dfpanel.iterrows():
    listrow = list(row[1])
    newlist = [x for x in listrow if pd.isnull(x) == False and x != 'nan']   
    panellen = (len(newlist))-2
    tempsum = tempsum + panellen
averagesize = tempsum/2

randompanel = shuffle(verifysigdf, averagesize)
randompanel.to_csv('randompaneldata.gmt', sep='\t', index=False)