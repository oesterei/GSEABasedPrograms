# -*- coding: utf-8 -*-
"""
Created on Mon Dec 20 15:54:06 2021
@author: Laura K. Harris, Ph.D.
"""

import pandas as pd
import gseapy as gp
import matplotlib.pyplot as plt

def prerankGSEA(refsigdf, folder, queryset, datasetnum):
    outputdir = 'output' + str(folder) + str(datasetnum)
    preresult = gp.prerank(refsigdf, queryset, outdir=outputdir, pheno_pos='Pos', pheno_neg='Neg',
            min_size=15, max_size=500, permutation_num=1000, weighted_score_type=1,
            ascending=False, processes=1, figsize=(6.5,6), format='jpg',
            graph_num=20, no_plot=True, seed=None, verbose=False)
    preresult.run()

#Random model
verifysigdf = pd.read_csv('output\Tscoredata1.txt', low_memory=False, delimiter = "\t", index_col=0)
verifysigdf.drop(verifysigdf.columns[1], inplace=True, axis=1)

prerankGSEA(verifysigdf, '\GSEAGeneverify', 'randompaneldata.gmt', 4)

#now to visualize the results
dfNES = pd.read_csv('output\GSEAGeneverify3\gseapy.prerank.gene_sets.report.csv', low_memory=False)
dfNEScol = dfNES["nes"]
dfrandomNES = pd.read_csv('output\GSEAGeneverify4\gseapy.prerank.gene_sets.report.csv', low_memory=False)
dfrandomNEScol = dfrandomNES["nes"]
pospanel = dfNEScol[1]
negpanel = dfNEScol[0]

fig, ax = plt.subplots()
line1 = ax.boxplot(dfrandomNEScol, vert=0, patch_artist=True, meanline=True, showmeans=True)
line2 = ax.scatter(pospanel, 1, marker="D", color = "red", label = "positive panel")
line3 = ax.scatter(negpanel, 1, marker="D", color = "blue", label = "negative panel")
plt.yticks([1], [''])
plt.xlabel('Randomly Generated Normalized Enrichment Scores')
ax.legend(handles=[line2, line3])
plt.show()