# -*- coding: utf-8 -*-
"""
Created on Mon Dec 20 15:54:06 2021
@author: Laura K. Harris, Ph.D.
"""

import os
import numpy as np
import pandas as pd
import gseapy as gp
import matplotlib.pyplot as plt


def prerankGSEA(refsigdf, queryset, path):
    randomNES = []
    count = 0
    gene_list = list(refsigdf.index.values)
    correl_vector = list(refsigdf['Tscore'])
    for index, row in queryset.iterrows():
        es, esnull, hit_ind, RES = gp.algorithm.enrichment_score(gene_list, 
                        correl_vector, row, weighted_score_type=1, nperm=1000)
        negesnull = []
        posesnull = []
        for i in esnull:
            if i < 0:
                negesnull.append(i)
            else:
                posesnull.append(i)
        if es < 0:
            meannegesnull = np.mean(negesnull)
            NES = es / abs(meannegesnull)
        else:
            meanposesnull = np.mean(posesnull)
            NES = es / abs(meanposesnull)
        if count % 20 == 0: 
            print('Item being analyzed = {}'.format(count))
        randomNES.append(NES)
        count = count + 1
    tempdf = pd.DataFrame(randomNES, columns=["colummn"])
    saveloc = path + '\\randomNES.txt'
    tempdf.to_csv(saveloc, index=False)
    return randomNES
        

#Import files
verifysigdf = pd.read_csv('output\Tscoredata1.txt', low_memory=False, delimiter = "\t", index_col=0)
verifysigdf.drop(verifysigdf.columns[1], inplace=True, axis=1)
randomsigdf = pd.read_csv('randompaneldata.gmt', low_memory=False, delimiter = "\t", header=0, index_col=0)
randomsigdf.drop(randomsigdf.columns[0], inplace=True, axis=1)

#Random model
cwd = os.getcwd()
path = cwd + "\output"
dfrandomNES = prerankGSEA(verifysigdf, randomsigdf, path)

#now to visualize the results
dfNES = pd.read_csv('output\GSEAGeneverify3\gseapy.prerank.gene_sets.report.csv', low_memory=False)
dfNEScol = dfNES["nes"]
pospanel = dfNEScol[1]
negpanel = dfNEScol[0]

fig, ax = plt.subplots()
line1 = ax.boxplot(dfrandomNES, vert=0, patch_artist=True, meanline=True, showmeans=True)
line2 = ax.scatter(pospanel, 1, marker="D", color = "red", label = "positive panel")
line3 = ax.scatter(negpanel, 1, marker="D", color = "blue", label = "negative panel")
plt.yticks([1], [''])
plt.xlabel('Randomly Generated Normalized Enrichment Scores')
ax.legend(handles=[line2, line3])
saveloc = path + '\\randomNESboxwhisplot.png'
plt.savefig(saveloc, dpi=100)
plt.show()